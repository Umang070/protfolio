function Fill2(props) {
  return <img className="fill-2" src={props.fill2} alt="Fill 2" />;
  // return null;
}

export default Fill2;
