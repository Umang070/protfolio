import './Fill.css';
function Fill1(props) {
  return <img className="fill-1" src={props.fill1} alt="fill 1" />;
}

export default Fill1;
